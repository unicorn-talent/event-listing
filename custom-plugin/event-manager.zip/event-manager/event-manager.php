<?php
/**
 * @package event-manager
 */
/*
Plugin Name: Event Manager
Description: This is a plugin that creates a new custom post type for events with fields for the event title, date, location, and description.
Version: 1.0
Author: Julian Kevin
*/


/**
 * Register a custom post type for events.
 */
function register_event_post_type() {
  // Register the custom post type 'event' with the following settings.
  register_post_type('event', array(
      'labels' => array(
          'name' => 'Events',
          'singular_name' => 'Event',
      ),
      'public' => true,
      'has_archive' => true,
      'supports' => array('title', 'editor', 'custom-fields'),
  ));
}
// Hook into WordPress initialization to register the custom post type.
add_action('init', 'register_event_post_type');


// Function to add a custom meta box for the 'event' custom post type
function event_custom_fields_metabox() {
  add_meta_box(
      'event-custom-fields',
      'Event Details',
      'render_event_custom_fields',
      'event',
      'normal',
      'default'
  );
}
add_action('add_meta_boxes', 'event_custom_fields_metabox'); // Hook to add the meta box

// Function to render the HTML input fields for custom fields
function render_event_custom_fields($post) {
  // Retrieve the existing custom field values for the post
  $event_date = get_post_meta($post->ID, 'event_date', true);
  $event_location = get_post_meta($post->ID, 'event_location', true);
  $event_description = get_post_meta($post->ID, 'event_description', true);

  // Render HTML input fields for each custom field
  ?>
  <label for="event_date">Event Date:</label>
  <input type="text" id="event_date" name="event_date" value="<?php echo esc_attr($event_date); ?>" />

  <label for="event_location">Event Location:</label>
  <input type="text" id="event_location" name="event_location" value="<?php echo esc_attr($event_location); ?>" />

  <label for="event_description">Event Description:</label>
  <textarea id="event_description" name="event_description"><?php echo esc_textarea($event_description); ?></textarea>
  <?php
}

// Function to save custom field data when the post is updated or saved
function save_event_custom_fields($post_id) {
  // Check if the post is being autosaved to prevent unnecessary updates
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  
  // Check if the custom field values are set in the $_POST data
  if (isset($_POST['event_date'])) {
      update_post_meta($post_id, 'event_date', sanitize_text_field($_POST['event_date']));
  }

  if (isset($_POST['event_description'])) {
      update_post_meta($post_id, 'event_description', sanitize_text_field($_POST['event_description']));
  }

  if (isset($_POST['event_location'])) {
      update_post_meta($post_id, 'event_location', sanitize_text_field($_POST['event_location']));
  }
}
// Hook to save custom field data when the post is updated or saved
add_action('save_post', 'save_event_custom_fields');

/**
 * Callback function for retrieving all events from the WordPress database.
 *
 * @return array An array with event data or an error response.
 */
function get_all_events_callback() {
  try {
    // Define the query parameters to retrieve all events of the 'event' post type.
    $args = array(
      'post_type' => 'event',
      'posts_per_page' => -1,
    );

    // Get the list of events based on the query parameters.
    $events = get_posts($args);

    if (!empty($events)) {
      $event_data = array();

      // Iterate through each event and build event information.
      foreach ($events as $event) {
        $event_title = $event->post_title;
        $event_date = get_post_meta($event->ID, 'event_date', true);
        $event_location = get_post_meta($event->ID, 'event_location', true);

        $event_info = array(
          'id' => $event->ID,
          'title' => $event_title,
          'date' => $event_date,
          'location' => $event_location,
        );

        $event_data[] = $event_info;
      }

      // Prepare a success response.
      $responseData = array(
        "code" => 200,
        "message" => "Success",
        "data" => $event_data
      );

      return $responseData;
    } else {
      // Prepare a 404 response when there are no events.
      $responseData = array(
        "code" => 404,
        "message" => "There are no events",
        "data" => array()
      );
      return $responseData;
    }
  } catch (Exception $e) {
    // Handle the exception, log it, or return an error response
    $responseData = array(
      "code" => 500,
      "message" => "Error: " . $e->getMessage(),
      "data" => array()
    );
    return $responseData;
  }
}

/**
 * Register the API route for retrieving all events.
 */
function register_get_all_events_route() {
  register_rest_route('event-manager', '/get-all-events', array(
      'methods' => 'GET',
      'callback' => 'get_all_events_callback',
  ));
}

// Hook into WordPress REST API initialization to register the get all events route.
add_action('rest_api_init', 'register_get_all_events_route');


/**
 * Callback function for retrieving an event by its ID from the WordPress database.
 *
 * @param WP_REST_Request $request The REST API request.
 *
 * @return array An array with event data or an error response.
 */
function get_event_by_id_callback($request) {
  try {
    // Retrieve the event ID parameter from the request.
    $event_id = $request->get_param('id');

    // Check if the event ID parameter is missing.
    if (!$event_id) {
      throw new Exception('Event ID parameter is missing');
    }

    // Get the event post by its ID.
    $event = get_post($event_id);

    // Check if the event is not found or is not of the 'event' post type.
    if (empty($event) || $event->post_type !== 'event') {
      throw new Exception('Event not found');
    }

    // Extract event data
    $event_title = $event->post_title;
    $event_date = get_post_meta($event->ID, 'event_date', true);
    $event_location = get_post_meta($event->ID, 'event_location', true);
    $event_description = get_post_meta($event->ID, 'event_description', true);

    // Build an array with event information
    $event_info = array(
      'title' => $event_title,
      'date' => $event_date,
      'location' => $event_location,
      'description' => $event_description,
    );

    // Prepare a success response.
    $responseData = array(
      "code" => 200,
      "message" => "Success",
      "data" => $event_info
    );

    return $responseData;
  } catch (Exception $e) {
    // Handle the exception, log it, or return an error response
    return new WP_Error(500, $e->getMessage(), array());
  }
}

/**
 * Register the API route for retrieving an event by its ID.
 */
function register_get_event_by_id_route() {
  register_rest_route('event-manager', '/get-event/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'get_event_by_id_callback',
  ));
}

// Hook into WordPress REST API initialization to register the get event by ID route.
add_action('rest_api_init', 'register_get_event_by_id_route');


/**
 * Callback function for retrieving events by title search from the WordPress database.
 *
 * @param WP_REST_Request $request The REST API request.
 *
 * @return array An array with event data matching the search or an error response.
 */
function get_events_by_title_callback($request) {
  try {
    // Retrieve the search text parameter from the request.
    $search_text = $request->get_param('search_text');
  
    // Define query arguments to search for events with the given title.
    $args = array(
      'post_type' => 'event',
      'posts_per_page' => -1,
      's' => $search_text, 
    );
  
    // Get a list of events matching the search query.
    $events = get_posts($args);
  
    if (!empty($events)) {
      $event_data = array();
  
      // Iterate through the retrieved events and extract relevant data.
      foreach ($events as $event) {
        $event_title = $event->post_title;
        $event_date = get_post_meta($event->ID, 'event_date', true);
        $event_location = get_post_meta($event->ID, 'event_location', true);
  
        // Build an array with event information for each matching event.
        $event_info = array(
          'id' => $event->ID,
          'title' => $event_title,
          'date' => $event_date,
          'location' => $event_location,
        );
  
        $event_data[] = $event_info;
      }
  
      // Prepare a success response with the matching event data.
      $responseData = array(
        "code" => 200,
        "message" => "Success",
        "data" => $event_data
      );
  
      return $responseData;
    } else {
      // Return a 404 response if no events matching the search were found.
      $responseData = array(
        "code" => 404,
        "message" => "There are no events",
        "data" => array()
      );
  
      return $responseData;
    }
  } catch (Exception $e) {
    // Handle exceptions, log them, or return an error response if an error occurs.
    return new WP_Error(500, $e->getMessage(), array());
  }
}

/**
 * Register the API route for retrieving events by title search.
 */
function register_get_events_by_title_route() {
  register_rest_route('event-manager', '/get-events-by-title', array(
    'methods' => 'GET',
    'callback' => 'get_events_by_title_callback',
    'args' => array(
      'search_text' => array(
        'sanitize_callback' => 'sanitize_text_field',
      ),
    ),
  ));
}

// Hook into WordPress REST API initialization to register the get events by title route.
add_action('rest_api_init', 'register_get_events_by_title_route');
